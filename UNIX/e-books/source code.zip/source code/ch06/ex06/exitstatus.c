#include <stdio.h>

int main(int argc,char* argv[]){
  int ec= atoi(argv[1]);
  return ec;
}
