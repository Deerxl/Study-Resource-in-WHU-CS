#include <stdio.h>
#include <stdlib.h>
main(){
    int pid;
    pid = fork();
    if ( pid < 0 ){
        printf("fork failed!");
        exit(1);
    }
    if( pid == 0){
        printf("this is child process\n");
    }
    else{
        printf("This is the parent process\n");
    }
}
