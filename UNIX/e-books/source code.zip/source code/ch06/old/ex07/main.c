#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){
    pid_t pid;
  int n;
  printf("fork program starting\n");
  pid = fork();
  switch(pid)
  {
   case 0:
     sleep(15);     
     printf("exit from child process\n");
     exit(0);
   default:
     sleep(5);
     printf("exit from parent process\n");
     break;
  }
 exit(EXIT_SUCCESS);
}

