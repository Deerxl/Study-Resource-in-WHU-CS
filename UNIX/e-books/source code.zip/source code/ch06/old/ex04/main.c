#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *fp;
    fp = fopen("a.txt","w");
    if(!fp)
        return 1;
    int pid = fork();
    if ( pid < 0 ){
        printf("fork failed!");
        exit(1);
    }
    if( pid == 0){
        fprintf(fp,"in child process\n");
    }
    else{
        sleep(2);
        fprintf(fp,"in the parent process\n");
    }
    fclose(fp);
}
