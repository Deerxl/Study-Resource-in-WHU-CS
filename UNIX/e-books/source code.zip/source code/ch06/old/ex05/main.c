#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
    int i=6;
    int pid = fork();
    if ( pid < 0 ){
        printf("fork failed!");
        exit(1);
    }
    if( pid == 0){
        execlp("ls","ls","-al");
        printf("in the child process,i=%d\n",i);
    }
    else{
        sleep(2);
        printf("in the parent process,i=%d\n",i);
    }
}
