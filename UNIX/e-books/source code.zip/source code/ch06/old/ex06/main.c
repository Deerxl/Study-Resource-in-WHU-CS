#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){
    pid_t pid;
  int n;
  printf("fork program starting\n");
  pid = fork();
  switch(pid)
  {
   case 0:     
     exit(7);
   default:
     sleep(5);
     wait(&n);
     printf("exit status word is %d\n",n);
     printf("exit status = %d\n",WEXITSTATUS(n));
     break;
  }
 exit(EXIT_SUCCESS);
}

