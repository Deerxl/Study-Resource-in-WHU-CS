#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){
  pid_t pid;
  int n;
  printf("no fork and wait\n");
  pid = wait(&n);
  printf("pid=%d\n",pid);
  printf("exit status word is %d\n",n);
  printf("exit status = %d\n",WEXITSTATUS(n));
  exit(EXIT_SUCCESS);
}

