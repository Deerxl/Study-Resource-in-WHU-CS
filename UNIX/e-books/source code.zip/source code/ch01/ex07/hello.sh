#!/bin/sh
#######################
# Name: echohello.sh
# Usage: print ‘Hello, World’
# Author: Gene
# Date: 2005-03-18
#######################
echo 'Hello, World!'
echo "nihao!"
echo `hello`
echo `ls`
