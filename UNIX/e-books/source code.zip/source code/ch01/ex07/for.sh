#!/bin/sh
#####################
# Name: for.sh
# Usage: Test for-do-done
# ……
#####################
for file in ./*
do
	echo $file
done

