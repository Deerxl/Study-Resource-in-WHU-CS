x='005'
y=5
[ $x = $y ]
echo $?
[ $x -eq $y ]
echo $?
