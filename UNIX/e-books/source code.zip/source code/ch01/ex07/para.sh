	#!/bin/sh
	################################################
	# Name: para.sh
	# Usage: Test the reserved parameters
	# ……
	################################################
	
	echo There are $# parameters
	echo The parameters are $@
	echo The Shell\’s PID is $$
	echo Test finished!

