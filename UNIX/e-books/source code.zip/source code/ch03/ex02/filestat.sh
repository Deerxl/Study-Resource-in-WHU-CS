ls -l /etc/passwd
read -p "$*"  #pause
ls -l /dev/log
read -p "$*"  #pause
ls -l /dev/tty
read -p "$*"  #pause
ls -l /dev/sr0
read -p "$*"  #pause
ls -l /dev/cdrom
read -p "$*"  #pause
ls -al .
