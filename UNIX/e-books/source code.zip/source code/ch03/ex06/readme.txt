If the current user doesn't have the permission to read or write to a file, can he delete the file?
