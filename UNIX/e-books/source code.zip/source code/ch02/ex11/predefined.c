#include <stdio.h>
#ifndef BUFFERSIZE
#define BUFFERSIZE 100
#endif
int main(){
    printf("%d\n",BUFFERSIZE);
}
