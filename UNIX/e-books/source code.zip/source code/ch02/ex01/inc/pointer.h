void testptr();
