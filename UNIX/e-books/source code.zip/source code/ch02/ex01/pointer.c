#include <stdio.h>

void examine(){
    int x=1;
    int y=7;
    int *p;
    p=&x;
    printf("%d",*p);
    p++;
    printf("  %d\n",*p);
    p=&y;
    printf("%d",*p);
    p++;
    //printf("  %p  ",p);
    printf("  %d\n",*p);
    printf("\n");
}

int main(){
    int i=5;
    int j=6;
    int *p;
    p=&i;
    printf("%p\n",p);
    p=&j;
    printf("%p\n",p);
    p++;
    printf("%p\n\n",p);
    examine();
}
