#include "pointer.h"

int main(){
    testptr();
    return 0;
}
