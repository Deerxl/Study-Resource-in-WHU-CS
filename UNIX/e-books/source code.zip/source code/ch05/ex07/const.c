#include <stdio.h>

int main(){
    char *p="abc";
    p[0]='1';
    printf("%s\n",p);
    return 0;
}
