#include <stdio.h>
int main(){
    int x = add(3,4);
    printf("x is %d\n",x);
}
