#include <stdio.h>

extern char **environ;
int main(int arc, char* argv[]){
    int i=0;
    while(environ[i])
        printf("%s\n",environ[i++]);
}
