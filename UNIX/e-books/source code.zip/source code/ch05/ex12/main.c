#include <stdio.h>
#include <stdlib.h>

int main(int arc, char* argv[]){
    printf("the environment var PATH is:%s\n",getenv("PATH"));
    printf("the environment var HOME is:%s\n",getenv("HOME"));
    putenv("HOME=/root");
    printf("the environment var HOME is:%s\n",getenv("HOME"));
    //while(environ[i])
        //printf("%s\n",environ[i++]);
}
