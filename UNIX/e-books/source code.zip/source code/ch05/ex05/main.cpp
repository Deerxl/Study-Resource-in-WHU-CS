#include <iostream>

int main(){
    std::cout << "please execute: echo $?, to see the return code of this program" << std::endl;
}
