﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
namespace FindMAC
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }
        [DllImport("Iphlpapi.dll")]
        private static extern int SendARP(
        Int32 dest, Int32 host, ref Int64 mac, ref Int32 length);
        [DllImport("Ws2_32.dll")]
        private static extern Int32 inet_addr(string ip);

        private string RemoteIpToMac(string destIp)
        {
            string temp1 = "", temp2 = "";
            try
            {
                StringBuilder macAddress = new StringBuilder();
                Int32 remote = inet_addr(destIp);
                Int64 macInfo = new Int64();
                Int32 length = 6;
                SendARP(remote, 0, ref macInfo, ref length);
                if (length == 0)
                {
                    temp2 = "";
                }
                else
                {
                    //两个字符代表一个字节
                    temp1 = Convert.ToString(macInfo, 16).PadLeft(12, '0').ToUpper();
                    for (int i = 0; i < 6; i++)
                    {
                        temp2 = temp2 + temp1.Substring(10 - i * 2, 2);
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("IpToMac" + err.Message);
            }
            return temp2;
        }


        private void button1_Click(object sender, EventArgs e)
        {

            alIPAndMac = new ArrayList();
            qIps = new Queue();
            for (int i = 1; i < 95; i++)
            {
                string strOneIp = textBox2.Text.Trim() + "." + i.ToString();
                qIps.Enqueue(strOneIp);
            }

            ThreadStart theStart = new ThreadStart(SearchAllMac);
            Thread theThr = new Thread(theStart);
            theThr.Start();
        }

        IntPtr MainWndHandle;
        public static Queue qIps;
        ArrayList alIPAndMac;
        public static string strIpAndMac;
        public static string strOneIp;

        public static ManualResetEvent mreTerminateSearch;

        private void SearchAllMac()
        {
            string strMacRe;

            while ((qIps.Count > 0) && !(mreTerminateSearch.WaitOne(1)))
            {
                strOneIp = (string)qIps.Dequeue();
                SendMessage(MainWndHandle, TESTONEIP, 100, 100);
                strMacRe = RemoteIpToMac(strOneIp);
                if (strMacRe.Length > 0)
                {
                    //删除已返回正确MAC地址的IP 
                    strIpAndMac = strOneIp + "#" + RemoteIpToMac(strOneIp);
                    SendMessage(MainWndHandle, GETONEMAC, 100, 100);
                }
                else
                {
                    //重新入队列
                    qIps.Enqueue(strOneIp);
                }
            }
        }
        [DllImport("User32.dll")]
        private static extern int SendMessage(
        IntPtr hWnd,
        int Msg,
        int wParam,
        int lParam
        );
        public const int GETONEMAC = 0x500;
        public const int TESTONEIP = 0x501;

        private void DetectFiles()
        {
            FileInfo finSelf = new FileInfo(Application.ExecutablePath);
            string[] allTxtFiles = Directory.GetFiles(finSelf.DirectoryName, "*.txt");


            comboBox1.Items.Clear();
            for (int i = 0; i < allTxtFiles.Length; i++)
            {
                FileInfo fin = new FileInfo(allTxtFiles[i]);
                comboBox1.Items.Add(fin.Name);
            }
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.Text = comboBox1.Items[0].ToString();
            }
        }
        private void FrmMain_Load(object sender, EventArgs e)
        {

            DetectFiles();
            MainWndHandle = this.Handle;
            mreTerminateSearch = new ManualResetEvent(false);
            
        }

        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case GETONEMAC:
                    //收到一个MAC信息
                    alIPAndMac.Add(strIpAndMac);
                    textBox1.AppendText(strIpAndMac + "\r\n");
                    break;
                case TESTONEIP:
                    //测试一个IP地址 
                    //textBox2.Text = strOneIp;
                    break;
                default:
                    base.DefWndProc(ref m);
                    break;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("AllMac.txt", false, Encoding.UTF8);
            sw.Write(textBox1.Text);
            sw.Close();
            sw.Dispose();
            MessageBox.Show(this, "Mac已保存，请按实验室保存名称");
        }
        static string strNetBroadcastIp;
        private void button3_Click(object sender, EventArgs e)
        {
            macFileName = comboBox1.Text;
            if (File.Exists(macFileName))
            {
                strNetBroadcastIp = textBox2.Text.Trim() + ".255";
                ThreadStart theStart = new ThreadStart(BootAll);
                Thread theThr = new Thread(theStart);
                theThr.Start();
            }

        }
        public static string macFileName;
        private void BootAll()
        {
            ArrayList alMac = new ArrayList();
            string oneLine, oneMac;
            StreamReader sr = new StreamReader(macFileName, Encoding.UTF8);
            oneLine = sr.ReadLine();
            while (oneLine != null)
            {
                oneMac = oneLine.Substring(oneLine.IndexOf("#") + 1);
                alMac.Add(oneMac);
                oneLine = sr.ReadLine();
            }
            sr.Close();
            sr.Dispose();

            Socket socket_send;
            //IPEndPoint iep;
            //EndPoint ep;
            //设置缓冲数据流
            byte[] send_data_buf;
            int send_data_len;
            IPEndPoint RemoteIpEndPoint;
            send_data_buf = new byte[1024];
            //初始化一个Scoket协议
            socket_send = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            //设置该scoket实例的发送形式
            socket_send.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);
            //发送端
            //初始化一个发送广播和指定端口的网络端口实例

            RemoteIpEndPoint = new IPEndPoint(IPAddress.Parse(strNetBroadcastIp), 9095);
            try
            {
                //获取的网卡的MAC地址为44-37-E6-03-16-01
                byte[] b_txt1 = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
                byte[] b_txt2 = { 0x44, 0x37, 0xe6, 0x03, 0x16, 0x01 };
                Buffer.BlockCopy(b_txt1, 0, send_data_buf, 0, 6);
                for (int i = 0; i < alMac.Count; i++)
                {
                    //依次填充网卡的MAC地址
                    oneMac = alMac[i].ToString();

                    for (int i2 = 0; i2 < 6; i2++)
                    {
                        b_txt2[i2] = Byte.Parse(oneMac.Substring(i2 * 2, 2), System.Globalization.NumberStyles.HexNumber);
                    }
                    for (int i1 = 1; i1 <= 16; i1++)
                    {
                        Buffer.BlockCopy(b_txt2, 0, send_data_buf, 6 * i1, 6);
                    }
                    send_data_len = 6 * 17;
                    socket_send.SendTo(send_data_buf, send_data_len, SocketFlags.None, RemoteIpEndPoint);
                }
            }
            catch (Exception e2)
            { }
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            mreTerminateSearch.Set();
        }
        public static void SetIPAddress(string oneip, string onesubmask, string onegateway, string onedns)
        {
            //ip = new string[1]{"192.168.2.119"};
            //submask = new string[1]{"255.255.255.0"};
            //getway = new string[1] {"192.168.2.2"};
            //dns = new string[2] { "211.68.71.4", "211.68.71.5" }; 

            string[] ip = new string[1];
            ip[0] = oneip;
            string[] submask = new string[1];
            submask[0] = onesubmask;
            string[] gateway = new string[1];
            gateway[0] = onegateway;
            string[] dns = new string[1];
            dns[0] = onedns;

            ManagementClass wmi = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = wmi.GetInstances();
            ManagementBaseObject inPar = null;
            ManagementBaseObject outPar = null;
            string macStr;
            foreach (ManagementObject mo in moc)
            {
                //如果没有启用IP设置的网络设备则跳过
                //if (!(bool)mo["IPEnabled"])
                //continue;

                string moCaption = mo["Caption"].ToString();
                if (!moCaption.Equals("[00000007] Killer e2200 Gigabit Ethernet Controller (NDIS 6.30)"))
                    continue;
                else
                    //MessageBox.Show((string)mo["caption"]); 
                    macStr = mo["MacAddress"].ToString();
                //设置IP地址和掩码
                if (ip != null && submask != null)
                {
                    inPar = mo.GetMethodParameters("EnableStatic");
                    inPar["IPAddress"] = ip;
                    inPar["SubnetMask"] = submask;
                }
                outPar = mo.InvokeMethod("EnableStatic", inPar, null);
                macStr = outPar["returnValue"].ToString();
                //设置网关地址
                if (gateway != null)
                {
                    inPar = mo.GetMethodParameters("SetGateways");
                    inPar["DefaultIPGateway"] = gateway;
                }
                outPar = mo.InvokeMethod("SetGateways", inPar, null);
                macStr = outPar["returnValue"].ToString();
                //设置DNS地址
                if (dns != null)
                {
                    inPar = mo.GetMethodParameters("SetDNSServerSearchOrder");
                    inPar["DNSServerSearchOrder"] = dns;
                }
                outPar = mo.InvokeMethod("SetDNSServerSearchOrder", inPar, null);
                macStr = outPar["returnValue"].ToString();
            }
        }



        /// <summary>
        /// 启用DHCP服务器
        /// </summary>
        public static void EnableDHCP()
        {
            ManagementClass wmi = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = wmi.GetInstances();
            foreach (ManagementObject mo in moc)
            {
                if (!mo["Caption"].ToString().Equals("[00000012] Realtek RTL8168/8111 PCI-E Gigabit Ethernet NIC"))
                    continue;
                else
                    MessageBox.Show((string)mo["caption"]);
                //如果没有启用IP设置的网络设备则跳过
                if (!(bool)mo["IPEnabled"])
                    continue;
                //重置DNS为空
                mo.InvokeMethod("SetDNSServerSearchOrder", null);
                //开启DHCP
                mo.InvokeMethod("EnableDHCP", null);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            SetIPAddress("172.16.12.188", "255.255.255.0", "172.16.12.254", "202.96.128.68");
        }
        public static void RemoteShutDown()
        {
            ConnectionOptions co = new ConnectionOptions();
            co.Username = "Administrator";
            co.Password = "";
            //co.Authority = "ntlmdomain:DOMAIN";
            System.Management.ManagementScope ms =
            new System.Management.ManagementScope("\\\\172.16.12.75\\root\\CIMV2", co);
            //查询远程计算机 　　
            try
            {
                ms.Connect();
            }
            catch (Exception)
            { 
            }
            
            System.Management.ObjectQuery oq = new System.Management.ObjectQuery("SELECT * FROM Win32_OperatingSystem");
            ManagementObjectSearcher query = new ManagementObjectSearcher(ms,oq);
            ManagementObjectCollection queryCollection = query.Get();
            foreach (ManagementObject mo in queryCollection)
            {
                mo.InvokeMethod("ShutDown",null);
            }

        }
        private void button5_Click(object sender, EventArgs e)
        {
            RemoteShutDown();
        }

    }
}
