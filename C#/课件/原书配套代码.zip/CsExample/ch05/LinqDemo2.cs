using System;
using System.Linq;
class LinqDemo2
{
	static void Main(string[] args)
	{
		string[] languages = { "Java", "C#", "C++", "Delphi", 
			"VB.net", "VC.net", "Perl", "Python" };
		var query = from item in languages
					group item by item.Length into lengthGroups
					orderby lengthGroups.Key
					select lengthGroups;
		foreach (var group in query)
		{
			Console.WriteLine("strings of length {0}", group.Key);
			foreach (var str in group)
			{
				Console.WriteLine(str);
			}
		}
	}
}
