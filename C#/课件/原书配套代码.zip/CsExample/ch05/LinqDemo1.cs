using System;
using System.Linq;
class LinqDemo1
{
	static void Main()
	{
		int[] arr = { 8, 5, 17, 24, 1, 2, 3, 12, 1 };
		var m = from n in arr where n > 5 orderby n descending select n;
		foreach (var n in m)
		{
			Console.WriteLine(n);
		}
	}
}
