using System;
using System.Collections.Generic;

public class YieldPower
{
    public static IEnumerable<long> Powers(int number, int exponent_from, int exponent_to)
    {
        int n = 1;
        int result = 1;
        while (n <= exponent_to)
        {
            result = result * number;
			n++;
            if( n>=exponent_from ) yield return result;
        }
    }

    static void Main()
    {
        foreach (int pw in Powers(2, 8, 16))
        {
            Console.Write("{0} ", pw);
        }
    }
}