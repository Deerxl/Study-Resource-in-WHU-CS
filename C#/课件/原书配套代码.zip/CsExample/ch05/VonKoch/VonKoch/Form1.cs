﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VonKoch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (graphics == null) graphics = this.CreateGraphics();

            width = this.Width - 30;
            height = this.Height - 30;
            curx = 10;
            cury = 50;

            graphics.FillRectangle(new SolidBrush(this.BackColor), 
                new Rectangle(0,0,this.Width, this.Height));

            int n = (int)this.numericUpDown1.Value;
            drawVonKoch(n, width);
        }

        private Graphics graphics;
        private int width;
        private int height;
        private double th, curx, cury;
        readonly double PI = Math.PI;
        readonly double m = 2 * (1 + Math.Cos(85 * Math.PI / 180));

        void drawVonKoch(int n, double d)
        {
            if (n == 0)
            {
                double x = curx + d * Math.Cos(th * PI / 180);
                double y = cury + d * Math.Sin(th * PI / 180);
                drawLineTo(x, y);
                return;
            }
            drawVonKoch(n - 1, d / m);
            th = th + 85;
            drawVonKoch(n - 1, d / m);
            th = th - 170;
            drawVonKoch(n - 1, d / m);
            th = th + 85;
            drawVonKoch(n - 1, d / m);
        }
        void drawLineTo(double x, double y)
        {
            graphics.DrawLine(
                Pens.Blue,
                (int)curx, (int)cury, (int)x, (int)y);
            curx = x;
            cury = y;
        }
    }
}
