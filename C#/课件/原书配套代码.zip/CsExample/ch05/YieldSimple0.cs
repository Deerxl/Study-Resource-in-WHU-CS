using System;
using System.Collections.Generic;
class YieldSimple0
{
	static IEnumerable<string> GetFruits()
	{
		yield return "apple";
		yield return "banana";
		yield return "orange";
	}

	static void Main()
	{
		var fruits = GetFruits();
		foreach( string fruit in fruits)
		{
			Console.WriteLine( fruit );
		}
	}
}