using System;
public static class ExtensionMethodString
{
	public static int WordCount( this string s )
	{
		string [] words = s.Split(" ,;.!".ToCharArray(),
			StringSplitOptions.RemoveEmptyEntries);
		return words.Length;
	}
}
class Demo
{
	static void Main( string [] args )
	{
		string s = "Hello world, C#!";
		int cnt = s.WordCount();
		Console.WriteLine(cnt);
	}
}
