using System;
using System.Collections;
public class HashtableTest  
{
	public static void Main()  
	{
		Hashtable ht = new Hashtable();
		ht.Add("Ton V. Bergyk", "023-010-66756");
		ht["Tom Sony"] = "086-010-27654";
		ht["Mr. John"] = "071-222-33445";

		foreach( object key in ht.Keys )
		{
			object value = ht[ key ];
			Console.WriteLine("\t{0}:\t{1}", key, value );
		}		
	}
}
