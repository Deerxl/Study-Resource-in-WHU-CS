using System;
using System.Collections.Generic;
public class StackTest 
{
	static readonly string[] months = 
	{ 
		"January", "February", "March", "April",
		"May", "June", "July", "August", "September",
		"October", "November", "December" 
	};
	public static void Main(string[] args) 
	{
		Stack<string> stk = new Stack<string>();
		foreach( string month in months)
			stk.Push(month);
		Console.WriteLine("popping elements:");
		while( stk.Count > 0 )
			Console.WriteLine(stk.Pop());
	}
}
