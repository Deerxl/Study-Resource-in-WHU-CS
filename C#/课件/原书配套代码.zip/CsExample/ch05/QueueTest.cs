using System;
using System.Collections.Generic;
public class QueueTest 
{
	static readonly string[] months = 
	{ 
		"January", "February", "March", "April",
		"May", "June", "July", "August", "September",
		"October", "November", "December" 
	};
	public static void Main(string[] args) 
	{
		Queue<string> que = new Queue<string>();
		foreach( string month in months)
			que.Enqueue(month);
		Console.WriteLine("Dequeue elements:");
		while( que.Count > 0 )
			Console.WriteLine(que.Dequeue());
	}
}
