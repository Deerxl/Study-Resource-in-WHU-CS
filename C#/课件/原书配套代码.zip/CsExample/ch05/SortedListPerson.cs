using System;
using System.Collections.Generic;
public class SortedListPerson  
{
	public static void Main()  
	{
		Person [] Persons = 
		{
			new Person( "Li ", true, 12 ),
			new Person( "Zhang", true, 18 ),
			new Person( "Tang", false, 23 ),
			new Person( "Chen", false, 37 ),
		};
		Random rnd = new Random();
		SortedList<Person,string> list1 = new SortedList<Person,string>();
		foreach( Person r in Persons )
			list1.Add( r, "Room:" + rnd.Next(1000) );
		PrintKeysAndValues( list1 );

		SortedList<Person,string> list2 = 
			new SortedList<Person,string>( list1, new MyComparer() );
		PrintKeysAndValues( list2 );
	}

	public struct Person : IComparable
	{
		public string Name;
		public bool Sex;
		public int Age;
		public Person( string name, bool sex, int age )
		{
			this.Name = name;
			this.Sex = sex;
			this.Age = age;
		}
		public int CompareTo( object obj2 )
		{
			if( ! (obj2 is Person) )
				throw new System.ArgumentException();
			Person rec2 = (Person) obj2;
			if( this.Age > rec2.Age ) return 1;
			else if( this.Age == rec2.Age ) return 0;
			return -1;
		}
		public override string ToString()
		{
			return "Name:"+Name + "\tSex:"+Sex +"\tAge:"+Age;
		}
	}

	public class MyComparer : IComparer<Person>
	{
		public int Compare( Person p1, Person p2 )
		{
			return p1.Name.ToLower().CompareTo( p2.Name.ToLower() );
		}
	}

	public static void PrintKeysAndValues<TKey,TValue>( SortedList<TKey,TValue> list )  
	{
		foreach( TKey t in list.Keys)
		{
			Console.WriteLine($"{t}:\t{list[t]}");
		}
	}
}
