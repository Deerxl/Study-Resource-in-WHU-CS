﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Runtime.CompilerServices;
using static System.Math;

namespace CsharpFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            CSharp5.CallerInfoDemo();
            new CSharp7().OutAndRefDemo();
        }
    }
    /// <summary>
    /// C# 2.0 特性介绍
    /// </summary>
    public class Csharp2
    {
        /// <summary>
        /// C#2.0重要改进：泛型(Generic)
        /// 泛型可以方便地处理不同类型
        /// </summary>
        public static void GenericDemo()
        {
            //使用泛型
            List<String> list = new List<String>();
            list.Add("aaa");
            string s = list[1];

            //如果不使用泛型，则要用强制类型转换
            System.Collections.ArrayList alist
                = new System.Collections.ArrayList();
            alist.Add("aaa");
            string s2 = (string)alist[1];
        }

        /// <summary>
        /// 分部类(partial classes)
        /// 一个类的不同分部可以分开写
        /// 比如窗体设计器生成的代码与用户写的代码分开
        /// </summary>
        public partial class Class1
        {
            void f1() { }
        }
        public partial class Class1
        {
            void f2() { }
        }

        /// <summary>
        /// 匿名方法 (anonymous methods)
        /// 可以不用单独定义一个有名字的方法
        /// </summary>
        public static void AnonymousMethodDemo()
        {
            //匿名方法，直接定义方法体，使用关键字delegate
            new Thread(delegate ()
            {
                //do somthing...
            });

            //如果以前，则必须定义一个有名字的方法体
            new Thread(new ThreadStart(MyFun));
        }
        public static void MyFun()
        {
            //do somthing...
        }

        /// <summary>
        /// 迭代器（Iterators）
        /// 可以方便地处理集合和迭代，使用关键词yield
        /// </summary>
        public static void IteratorDemo()
        {
            IEnumerable<int> nums = GetNums(10);
            foreach (int n in nums)
            {
                Console.WriteLine(n);
            }
        }
        public static IEnumerable<int> GetNums(int n)
        {
            int k = 1;
            int cnt = 0;
            while (cnt < n)
            {
                k++;
                if (IsPrime(k))
                {
                    cnt++;
                    yield return k;
                }
            }
        }
        public static bool IsPrime(int k)
        {
            for (int i = 2; i <= Math.Sqrt(k); i++)
                if (k % i == 0) return false;
            return true;
        }

        /// <summary>
        /// 可空类型（Nullable types）
        /// 可以方便地处理值类型为空值的情况
        /// </summary>
        public static void NullableDemo()
        {
            int? a = null;
            a = 23;
            if (a.HasValue)
            {
                int b = a.Value;
                Console.WriteLine(b);
            }
        }

        /// <summary>
        /// Getter与Setter可访问性不同 （Getter/setter separate accessibility）
        /// </summary>
        public class Class2
        {
            int _age;
            public int Age
            {
                get { return _age; }
                protected set { _age = value; }
            }
        }

        /// <summary>
        /// 静态类(static class)
        /// 所有的方法都是static的类
        /// 主要是一些工具类，如Math, File, Convert
        /// </summary>
        public static class MyUtilClass
        {
            public static bool DeleteFile(string path)
            {
                // do something...
                return true;
            }
        }

    }

    /// <summary>
    /// C# 3.0 特性介绍
    /// </summary>
    public static class Csharp3
    {
        /// <summary>
        /// C#3.0 重要特性： Lambda表达式
        /// Lambda表达式大大地简写了匿名函数、事件、委托参数
        /// 并使得高级函数、Linq等一系列特性成为可能
        /// </summary>
        public static void LambdaDemo()
        {
            new Thread(() =>
            {
                // do somthing ...
            });

            Button button1 = new Button();
            button1.Click += (sender, argv) =>
            {
                // event do somthing...
            };
        }

        /// <summary>
        /// C#3.0 重要特性： Linq（语言集成查询）
        /// Linq大大简化了对集合的处理的表达
        /// 更专注于“要什么”，而不是“怎么做”，相当于更高级的语言
        /// Linq 包括 Linq to Objects, Linq to XML 和 Linq to SQL 等
        /// </summary>
        public static void LinqDemo()
        {
            List<double> samples = new List<double>();
            for (int i = 0; i < 20; i++) samples.Add(i);

            //可以使用查询表达式语法（Query expressions）
            var query = from num in samples
                        where num < 10
                        orderby num descending
                        select new
                        {
                            num = num,
                            num2 = num * num,
                            num3 = num * num * num
                        };
            foreach (var item in query)
            {
                Console.WriteLine(item.num3);
            }

            //或者使用方法的写法
            var query2 = samples.Where(i => i < 10)
                .Take(10)
                .Select(i => i * i);
            double max = query2.Max();
            Console.WriteLine(max);
        }

        /// <summary>
        /// 隐式类型局部变量（Implicitly typed local variables）
        /// 可以方便地书写变量的类型，而由编译器来推断
        /// 大量地用于Linq或类型很复杂的场合
        /// </summary>
        public static void VarDemo()
        {
            var num = 0;
            var list = new List<int>();
            foreach (var i in list)
            {
                num += i;
            }

            var query = from i in list select i * i;
        }

        /// <summary>
        /// 扩展方法（Extension methods）
        /// 允许扩充任何类，对其添加方法（而不用继承原类）
        /// 这对Linq的实现也很有帮助
        /// </summary>
        public static void ExtensionMethodsDemo()
        {
            //如果要使用扩展方法，要using相关的类
            string s = "I like C#";
            int n = s.WordCount();
        }
        // 扩展方法必须写到public static类中
        // 方法的第一个参数以this修饰
        public static int WordCount(this string s)
        {
            return s.Split(' ').Length;
        }

        /// <summary>
        /// 对象与集合的初始化（Object and collection initializers）
        /// </summary>
        public static void InitDemo()
        {
            Form form = new Form
            {
                Text = "Caption",
                Width = 200,
                Height = 100,
            };

            List<int> list = new List<int> { 1, 2, 5, 9 };
        }

        /// <summary>
        /// 自动实现的属性(Auto-Implemented properties)
        /// 可以简写简单的属性
        /// </summary>
        class Person
        {
            public int Age { set; get; }
            public string Name { set; get; }
        }

        /// <summary>
        /// 匿名类型（Anonymous types）
        /// 系统自动定义其类型
        /// 常用于Linq
        /// </summary>
        public static void AnonymousTypeDemo()
        {
            var person = new { ID = 12, Name = "Tang", Age = 18 };

            var list = new List<double>();
            var query = from n in list
                        select new
                        {
                            Num = n,
                            Root = Math.Sqrt(n),
                        };
            var firstRoot = query.First().Root;
        }

        /// <summary>
        /// 分部方法（Partial methods）
        /// 常用于代码生成器等场合
        /// </summary>
        public partial class MyClass
        {
            //定义分部方法(没写实现体),返回类型必须是void
            partial void MakeTable(string tableName);
        }
        public partial class MyClass
        {
            //实现分部方法
            partial void MakeTable(string tableName)
            {
                //really do something...
            }
        }
    }

    /// <summary>
    /// C# 4.0 特性介绍
    /// </summary>
    public class CSharp4
    {
        /// <summary>
        /// C#4.0的重要特性：动态类型（Dynamically Typed Object）
        /// 使用dynamic声明的变量，在编译时不检查其类型，假定它具有某种方法
        /// 使用dynamic的好处在于，可以不去关心对象是来源于COM, IronPython, HTML DOM或者反射
        /// 在运行时，会具体调用其方法
        /// </summary>
        public static void DynamicDemo()
        {
            dynamic excel = null;
            //excel = GetExcel();
            excel.Cells(2, 3).Value = "aaa";
        }

        /// <summary>
        /// 命名参数及可选参数（Named and optional parameters）
        /// 写法类似于VB，当参数比较多时很方便
        /// 命名参数，可以让参数前后的顺序改变
        /// 可选参数，可以让函数调用书写更简单
        /// </summary>
        public static void UseParameter()
        {
            //使用命名参数
            var fs = new FileStream(mode: FileMode.Create, path: "aaa.txt");
            // 相当于 new FileStream("aaa.txt", FileMode.Create )

            //使用默认的可选参数
            int n = GetWordCount("I like C#");

            //在与COM交互时，可选参数更方便
            //doc.SaveAs("Test.docx");
            //而早期必须写为
            //object missing = System.Reflection.Missing.Value;
            //doc.SaveAs(ref fileName,
            //ref missing, ref missing, ref missing,
            //ref missing, ref missing, ref missing,
            //ref missing, ref missing, ref missing,
            //ref missing, ref missing, ref missing,
            //ref missing, ref missing, ref missing);
        }
        //使用等号（=）来定义可选参数的默认值
        public static int GetWordCount(string s, char seperator = ' ')
        {
            return s.Split(seperator).Length;
        }

        /// <summary>
        /// 泛型的协变与逆变（Covariance and Contravariance）
        /// 协变：使用out修饰符，某个返回的类型可以由其派生类型替换
        /// 逆变：使用in修饰符，某个参数类型可以由其基类型替换
        /// </summary>
        public static void CoContraVarianceDemo()
        {
            //IEnumerable<T> 接口的定义(支持协变)
            //public interface IEnumerable<out T> : IEnumerable;
            IEnumerable<Student> students = new List<Student>();
            IEnumerable<Person> people = students;
            foreach (Person p in people)
            {
                Console.WriteLine(p.Age);
            }

            //Action<T> 委托的定义(支持逆变)
            //public delegate void Action<in T>(T obj);
            Action<Person> showAge = p => Console.WriteLine(p.Age);
            Action<Student> introduce = showAge;
            introduce(new Student());

            //又如：Func<T,R> 委托的定义(T支持逆变,R支持协变)
            //System.Func<in T, …, out R>
        }
        class Person { public int Age { set; get; } }
        class Student : Person { }
    }

    /// <summary>
    /// C# 5.0 特性介绍
    /// </summary>
    public class CSharp5
    {
        /// <summary>
        /// C# 5.0重要特性：异步方法（Asynchronous methods）
        /// 使用async及await关键字
        /// </summary>
        async public static void AsyncDemo()
        {
            //常用于异步的IO
            FileStream fs = new FileStream("a.txt", FileMode.Create);
            await fs.WriteAsync(new byte[] { 32 }, 0, 1);

            //也用于耗时的操作
            long reslt = await Calcu(10);
        }
        //await所等待的是一个Task
        public static Task<long> Calcu(int n)
        {
            return Task.Run(() =>
            {
                long fac = 1;
                for (int i = 1; i <= n; i++) fac *= i;
                return fac;
            });
        }

        /// <summary>
        /// 调用者信息（Caller Information）
        /// 可以加上几个特殊的可选参数，用以表示调用者信息
        /// 系统会自动填充这些参数，主要用于调试或日志
        /// </summary>
        public static void CallerInfoDemo()
        {
            SayHello("Tang");
        }
        public static void SayHello(string someone,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0
        )
        {
            //memberName等可选参数会自动有值
            Console.WriteLine(memberName + "SayHello");
            Console.WriteLine("Hello, " + someone);
        }

    }

    /// <summary>
    /// C# 6.0 特性介绍
    /// </summary>
    public class CSharp6
    {
        /// <summary>
        /// C# 6.0重要特性：Rosyln（.NET的编译平台）
        /// 可以方便地编译、分析C#代码
        /// 由于这个特性主要用于编译平台，这里就不举例了
        /// </summary>

        /// <summary>
        /// 导入static类，可以直接使用方法
        /// using static System.Math;后
        /// </summary> 
        double a = Sqrt(7.8);

        /// <summary>
        /// 自动属性初始化及默认值
        /// </summary>
        public double X { get; set; } = 10;
        public double Y { get; } = 20;

        /// <summary>
        /// 表达式体成员（Expression-bodied members）
        /// 可以简写方法、属性、索引器
        /// </summary>
        public double Square(double n) => n * n; //方法
        public double Distance => Math.Sqrt(X * X + Y * Y); //只读性属性
        public string this[int x] => x + ""; //只读性索引器

        /// <summary>
        /// Null条件操作符
        /// 可以方便地处理null情况
        /// </summary>
        public void NullDemo()
        {
            Customer customer = new Customer();
            int? a = customer?.Orders?[5];
        }
        public class Customer
        {
            public List<int> Orders = new List<int>();
        }

        /// <summary>
        /// 字符串置入 （String interpolation）
        /// 在字符串前面用$，在字符串里面用{}表示变量或表达式
        /// </summary>
        public static void StringInterpolationDemo()
        {
            var person = new { age = 18, name = "Zhang" };
            string info = $"{person.name} is {person.age} years old";
            Console.WriteLine($"now is {DateTime.Now}, info : {info}");
        }

        /// <summary>
        /// nameof运算符
        /// 可以避免字符串写错
        /// 常用于json、数据库等场合
        /// </summary>
        public static void NameOfDemo()
        {
            int age = 10;
            string info = nameof(age) + ":" + age;
            string methodName = nameof(NameOfDemo);
        }

        /// <summary>
        /// 字典初始化
        /// 使用方括号及等号
        /// </summary>
        public void DictionaryDemo()
        {
            Dictionary<string, int> dict = new Dictionary<string, int>
            {
                ["cat"] = 1,
                ["dog"] = 5,
                ["rabbit"] = 6,
            };
        }

    }

    /// <summary>
    /// C# 7.0 特性介绍
    /// </summary>
    public class CSharp7
    {
        /// <summary>
        /// C#7.0 重要特性：元组（Tuple）
        /// 对于函数输出多个值更方便。
        /// 因为传统的函数只能返回一个值，如果要多个值，常用的方法主要是：
        /// （1）使用多个out参数，但不太方便，因为这几个参数不能做为一个整体；  
        /// （2）自定义一个类或结构来返回，也不方便，因为要多定义一个类或结构体；
        /// （3）使用System.Tuple<T1,T2,...>，缺点是这是引用类型，会产生多个对象；
        /// （4）使用匿名类或动态类(dynamic)，缺点是类型检查不方便
        /// C#7.0使用了System.ValueTuple<...>或ValueTuple字面量来解决这个问题。
        /// 其基本写法是使用圆括号来括起多个值。System.ValueTuple是值类型。
        /// 
        /// 要注意的是：要使用ValueTupe，需要在项目右击选“NuGet程序包管理器”
        /// 来下载System.ValueTuple程序包
        /// </summary>
        public void TuplesDemo()
        {
            //使用元组变量及元组字面量（tuple literals）
            (string, string, int) a = ("1002", "bbb", 18);

            //可以取得函数的返回值
            (string, string, int) a2 = SearchById("1001");

            //可以使用var 
            var a3 = SearchById("1001");

            //每个分量可以通过Item1,Item2,Item3等来访问
            Console.WriteLine($"{a.Item1}, {a.Item2}, {a.Item3}");

            //可以对分量取名字
            (string id, string name, int age) b = a;
            Console.WriteLine($"{b.id}, {b.name}, {b.age}");

            //可以直接解构(descrution)各分量，即直接定义多个变量
            (string id, string name, int age) = a;
            Console.WriteLine($"{id}, {name}, {age}");
        }
        //定义返回元组的
        (string, string, int) SearchById(string id)
        {
            return (id, "Zhang", 12);
        }
        //也可以对元组分量取名字
        (string id, string name, int age) SearchById2(string id)
        {
            return (id, "Zhang", 12);
        }

        /// <summary>
        /// 局部函数（Local functions）
        /// 可以在方法中定义一个函数
        /// 这样可以实现更好的封装性
        /// </summary>
        public void LocalFunctionDemo()
        {
            List<int> primes = new List<int>();
            for (int n = 2; n < 100; n++)
            {
                if (isPrime(n)) primes.Add(n);
            }

            bool isPrime(int n)
            {
                for (int i = 2; i < n; i++)
                {
                    if (n % i == 0) return false;
                }
                return true;
            }
        }

        /// <summary>
        /// 字面常量（literal）的改进
        /// 可以允许加下划线（_）表示数字分隔（它的位置可以随意写）
        /// 可以写以0b或0B开头的二进制
        /// </summary>
        public void LiteralDemo()
        {
            double a = 7_654_321.123;
            long b = 0xAA_EF_9D;
            int c = 0b0111_1111_1101;
        }

        /// <summary>
        /// out及ref变量的直接定义
        /// 函数可以返回ref变量
        /// </summary>
        public void OutAndRefDemo()
        {
            MyOut(5, out int b); //在调用的同时，定义out变量

            int[] nums = { 2, 3, 5, 7, 8 };
            ref int a = ref MyRef(5, nums); //a是一个引用型变量
            a = 100; //这将改变数组中的5变成100
        }
        public void MyOut(int a, out int b)
        {
            b = a * a;
        }
        public ref int MyRef(int a, int[] nums)
        {
            for (int i = 0; i < nums.Length; i++)
                if (nums[i] >= a) return ref nums[i];
            throw new Exception($"{nameof(a)}{a} not found");
        }

        /// <summary>
        /// 模式匹配（Pattern Matching）
        /// 可以在is及case中在判断变量类型的同时，直接定义该类型的变量
        /// （is一般用在if语句中，而case是switch语句中）
        /// </summary>
        public void PatternMatchingDemo()
        {
            object o = 5;
            int result = 0;
            //模式匹配用于is中
            if (o is int i) result = i; //直接定义了int变量i
            if (o is string s) int.TryParse(s, out result);

            //模式匹配用于case中
            switch (o)
            {
                case string str:
                    Console.WriteLine("a string");
                    int.TryParse(str, out result);
                    break;
                case int ii:
                    Console.WriteLine("an integer");
                    result = ii;
                    break;
            }
        }

    }
}

