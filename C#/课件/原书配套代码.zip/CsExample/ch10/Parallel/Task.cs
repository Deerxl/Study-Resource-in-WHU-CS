using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
class TaskDemo
{
	static void Main(string[] args)
	{
		Task<double>[] tasks = {
			Task.Run( ()=>SomeFun() ),
			Task.Run( ()=>SomeFun() ),
		};
		Thread.Sleep(1);
		for(int i=0; i<tasks.Length; i++ )
		{
			Console.WriteLine(tasks[i].Status);  //�鿴״̬
		}
		for(int i=0; i<tasks.Length; i++ )
		{
			Console.WriteLine(tasks[i].Result);  //�ȵ��������ȡ���
		}
		Task.WaitAll( tasks ); //Ҳ������������ȴ�����
	}

	static double SomeFun()
	{ 
		Thread.Sleep(50); 
		return DateTime.Now.Ticks; 
	}
}
