using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading;

namespace ParallelLoopDemo
{
    public class ParallelLoopCompare
    {
        static void Main()
        {
			int times = 20000;
            NormalLoop( times );
			ParallelLoop(times);
        }

        static void NormalLoop(int times)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            for (int i = 1; i < times+1; i++)
            {
                Calc(i);
            }
            sw.Stop();
            Console.WriteLine( sw.ElapsedMilliseconds );
        }

        static void ParallelLoop(int times)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            Parallel.For(1, times+1, i =>
            {
                Calc(i);
            });
            sw.Stop();
            Console.WriteLine( sw.ElapsedMilliseconds );
        }
        static void Calc(int n)
        {
			double f = 1;
            for(int i=1; i<=n; i++ ) f*=i;
        }
    }
}
