using System;
using System.Threading;
using System.Threading.Tasks;
class ParallelInvoke
{
	static void Main(string[] args)
	{
		Action[] actions = { new Action(DoSometing), DoSometing };
		Parallel.Invoke( actions ); 

		Console.WriteLine("�����������߳�"
			+Thread.CurrentThread.ManagedThreadId);
	}
	static void DoSometing(){ 
		Console.WriteLine("�Ӻ��������߳�"
			+Thread.CurrentThread.ManagedThreadId);
		Thread.Sleep(2000);
	}
}