using System;
using System.Linq;

class Program 
{
	static void Main()
	{
		int[] source = new int[1000];
		for(int i=0; i<source.Length; i++) source[i]=i;
		var result = source.AsParallel().Where(c => c >= 0);
		foreach (var d in result)
		{
			Console.WriteLine(d);
		}
	}
}