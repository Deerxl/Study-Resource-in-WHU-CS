using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

class T
{
	static void Main(string[] args)
	{
           int[] source = new int[1000];
            for (int i = 0; i < source.Length; i++)
				source[i] = i;

			var presult = source.AsParallel()
				.Select(c => Math.Pow(c, 3));
            foreach (var d in presult)
            {
                Console.WriteLine("AsParallel Result  is:{0}", d);
            }
            source.AsParallel().ForAll((d) =>
            {
                Console.WriteLine("ForAll result {0} ", d);
            });

            var result1 =
				from e in ParallelEnumerable.Range(0, 100)
				where e % 2 == 0
				select Math.Pow(e, 2);

            var result2 =
            ParallelEnumerable.Repeat(10, 1000)
            .Select(item => Math.Pow(item, 2));

            var result3 =
            Enumerable.Repeat(10, 1000)
            .Select(item => Math.Pow(item, 2));

	
						/*  // PARALLEL QUERY
            _parallelQuery = from b in _babies.AsParallel().WithDegreeOfParallelism(numProcs)
                             where b.Name.Equals(_userQuery.Name, StringComparison.InvariantCultureIgnoreCase) &&
                                   b.State == _userQuery.State &&
                                   b.Year >= YEAR_START && b.Year <= YEAR_END
                             orderby b.Year
                             select b; */

	}
}
