using System;
public class HelloWorldApp { //an application
	public static void Main (string []args){
		Console.WriteLine("Hello World!");
	}
}
