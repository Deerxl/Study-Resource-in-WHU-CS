using System;
class C
{
	static C()
	{
		Console.WriteLine( a  + "," + b );
	}
	public static int a = b+1;
	public static int b = a+1;
	static void Main()
	{
	}
}
