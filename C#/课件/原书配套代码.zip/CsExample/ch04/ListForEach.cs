using System;
using System.Collections.Generic;
public class ListForEach
{
	static void Main()
	{
		List<string> words = new List<string>(){ 
			"Apple", "Banana", "Orange", "Mango"};
		
		words.ForEach( s => Console.WriteLine(s) );
		
		int letters = 0;
		words.ForEach( s => letters += s.Length );
		Console.WriteLine(letters);
	}
}
