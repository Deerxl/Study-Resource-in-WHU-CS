using System;
using System.IO;
using System.Text;

class FileReadWriteText
{
    public static void Main()
    {
        string path = @"c:\temp\MyTest.txt";
		
		//�����ļ�(UTF8����)
        if (!File.Exists(path))
        {
            using (StreamWriter sw = File.CreateText(path))
            {
                sw.WriteLine("Hello");
                sw.WriteLine("And");
                sw.WriteLine("Welcome");
            }
        }

		//���ļ�(UTF8����)
        using (StreamReader sr = File.OpenText(path))
        {
            string s = "";
            while ((s = sr.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }
        }
    }
}
