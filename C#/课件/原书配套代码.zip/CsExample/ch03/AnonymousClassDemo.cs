using System;
class AnonymousClassDemo
{
	static void Main(string [] argv)
	{
		Object[] books = 
		{
			new { Title="C#", Author="Tang", Price=1.5 },
			new { Title="Java", Author="Zhang", Price=2.1},
		};
		Console.WriteLine(books.Length);
	}
}