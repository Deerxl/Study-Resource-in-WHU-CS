using System;
class A
{
	public int a = 10;
	public void m() {
		a++; Console.WriteLine(a);
	}
	public virtual void v(){
		Console.WriteLine("A.v");
	}
}
class B : A
{
	new public int a = 20;
	new public void m() { 
		a++; Console.WriteLine(a);
	}
	public override void v(){
		Console.WriteLine("B.v");
	}
	static void Main()
	{
		A x = new B(); 
		Console.WriteLine( x.a ); //��ʾ10
		x.m(); //��ʾ11
		B y = new B();
		Console.WriteLine( y.a ); //��ʾ20
		y.m(); //��ʾ21
		A z = new B();
		z.v(); //��ʾ"B.v"
	}
}
