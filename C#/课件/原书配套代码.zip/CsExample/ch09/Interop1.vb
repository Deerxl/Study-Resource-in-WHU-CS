Imports System
Imports Microsoft.VisualBasic
public Module Module1
	Public Sub Msg( a As String)
		MsgBox( a )
	End Sub
End Module
