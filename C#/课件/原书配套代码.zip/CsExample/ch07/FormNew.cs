using System.Windows.Forms;
public class A
{
	static void Main()
	{
		Form f = new Form();
		Application.Run( f );
	}
}